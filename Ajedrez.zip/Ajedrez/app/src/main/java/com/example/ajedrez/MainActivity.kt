
package com.example.ajedrez

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            TableroAjedrez()
        }
    }
}

@Composable
fun TableroAjedrez() {

    // Calculamos el tamaño de cada casilla
    val anchoPantalla = LocalConfiguration.current.screenWidthDp.dp
    val tamañoCasilla = (anchoPantalla - 44.dp) / 8

    // Fondo gris de la pantalla
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Gray),
        contentAlignment = Alignment.Center
    ) {
        // Contenedor blanco con borde rojo
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, Color.Red)
                .background(Color.White)
                .padding(10.dp)
        ) {

            Row {
                // Numeros del 1 al 8
                Column {
                    for (numero in 1..8) {
                        Box(
                            modifier = Modifier
                                .width(20.dp)
                                .height(tamañoCasilla),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$numero",
                                fontSize = 16.sp,
                                color = Color.Black
                            )
                        }
                    }
                }
                // Tablero
                Column {
                    // Creamos las 8 filas
                    for (fila in 0..7) {

                        Row {
                            // Creamos las 8 columnas
                            for (columna in 0..7) {

                                // Alternamos blanco y negro
                                val colorCasilla =
                                    if ((fila + columna) % 2 == 0) {
                                        Color.White
                                    } else {
                                        Color.Black
                                    }

                                // Dibujamos cada casilla
                                Box(
                                    modifier = Modifier
                                        .size(tamañoCasilla)
                                        .background(colorCasilla)
                                )
                            }
                        }
                    }

                    // Letras de la a hasta la h
                    Row {
                        for (letra in 'a'..'h') {

                            Box(
                                modifier = Modifier
                                    .width(tamañoCasilla)
                                    .height(30.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$letra",
                                    fontSize = 16.sp,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
